package com.example.contas_compartilhadas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
